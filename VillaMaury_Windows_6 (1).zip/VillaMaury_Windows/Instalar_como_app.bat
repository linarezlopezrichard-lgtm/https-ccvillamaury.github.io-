@echo off
chcp 65001 >nul
title Instalar Villa Maury como aplicacion
cd /d "%~dp0"
echo.
echo   Creando el icono "Villa Maury" en el escritorio...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0crear_acceso.ps1"
if errorlevel 1 (
  echo.
  echo   No se pudo completar. Lea el mensaje de arriba.
  pause
  exit /b 1
)
timeout /t 4 >nul
