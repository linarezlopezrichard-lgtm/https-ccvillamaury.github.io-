# Crea el icono "Villa Maury" en el escritorio y abre la aplicacion en su propia ventana.
$ErrorActionPreference = 'Stop'
$carpeta = Split-Path -Parent $MyInvocation.MyCommand.Path
$archivo = Join-Path $carpeta 'VillaMaury_Registro.html'
if (-not (Test-Path $archivo)) {
  Write-Host 'No se encontro VillaMaury_Registro.html en esta carpeta.'
  exit 1
}
$candidatos = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LocalAppData\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
)
$nav = $candidatos | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $nav) {
  Write-Host 'No se encontro Google Chrome ni Microsoft Edge. Instale Google Chrome y vuelva a intentarlo.'
  exit 1
}
$url = ([System.Uri]$archivo).AbsoluteUri
$argumentos = '--app="' + $url + '"'
$escritorio = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
$acceso = $ws.CreateShortcut((Join-Path $escritorio 'Villa Maury.lnk'))
$acceso.TargetPath = $nav
$acceso.Arguments = $argumentos
$acceso.WorkingDirectory = $carpeta
$ico = Join-Path $carpeta 'icono.ico'
if (Test-Path $ico) { $acceso.IconLocation = $ico }
$acceso.Description = 'Registro de grupos familiares - Villa Maury'
$acceso.Save()
Write-Host 'Listo: se creo el icono "Villa Maury" en el escritorio.'
Start-Process -FilePath $nav -ArgumentList $argumentos
